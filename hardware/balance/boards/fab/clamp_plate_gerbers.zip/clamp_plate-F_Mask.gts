%TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu24.04.1*%
%TF.CreationDate,2026-10-24T11:58:18-07:00*%
%TF.ProjectId,clamp_plate,636c616d-705f-4706-9c61-74652e6b6963,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu24.04.1) date 2026-10-24 11:58:18*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.400000*%
G04 APERTURE END LIST*
D10*
%TO.C,*%
X-5000000Y0D03*
%TD*%
%TO.C,*%
X5000000Y0D03*
%TD*%
M02*
