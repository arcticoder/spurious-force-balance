%TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu24.04.1*%
%TF.CreationDate,2026-10-24T11:58:22-07:00*%
%TF.ProjectId,clamp_ground,636c616d-705f-4677-926f-756e642e6b69,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu24.04.1) date 2026-10-24 11:58:22*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.400000*%
%ADD11C,3.200000*%
G04 APERTURE END LIST*
G36*
X-2800000Y6000000D02*
G01*
X2800000Y6000000D01*
X2800000Y-6000000D01*
X-2800000Y-6000000D01*
X-2800000Y6000000D01*
G37*
D10*
%TO.C,*%
X-5000000Y0D03*
%TD*%
%TO.C,*%
X5000000Y0D03*
%TD*%
D11*
%TO.C,*%
X6000000Y-9500000D03*
%TD*%
M02*
